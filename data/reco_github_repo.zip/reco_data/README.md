# Reco — Repositorio de Datos Públicos del Mercado Inmobiliario Peruano

## Estructura de archivos

```
reco_data/
├── README.md                        ← Este archivo
├── valores_arancelarios_mef.json    ← Valores arancelarios por zona/sector (USD/m²)
├── valores_arancelarios_flat.csv    ← Misma data en formato tabla CSV
├── valores_construccion_mef.json    ← Valores unitarios de construcción por categoría A-G (S/m²)
├── serie_precios_bcrp.json          ← Serie histórica BCRP + medianas 2025 por distrito
├── precios_distrito_2025.csv        ← Mediana/P25/P75 por distrito Lima 2025
├── zonificacion_lima_imp.json       ← Zonificación Lima: RDB/RDM/RDA/C2/C3/C5/I1/I2/ZRP
└── parametros_urbanisticos.csv      ← Parámetros edificatorios por zona (altura, coef, área libre)
```

## Fuentes de datos

| Archivo | Fuente | Instrumento legal | Acceso |
|---------|--------|-------------------|--------|
| valores_arancelarios_mef.json | MEF | RM N°255-2025-EF/15 | Público |
| valores_construccion_mef.json | MEF | RM N°255-2025-EF/15 | Público |
| serie_precios_bcrp.json | BCRP | Serie PN01289XM | API pública |
| zonificacion_lima_imp.json | IMP | PLAM 2035 / Ord. 2040-2021/MML | Público |
| parametros_urbanisticos.csv | IMP/MVCS | Ordenanzas municipales | Público |

## Fuentes que requieren convenio institucional

| Fuente | Datos | Contacto |
|--------|-------|---------|
| SUNARP | Partidas registrales, transferencias, cargas | gerencia.ti@sunarp.gob.pe |
| SAT Lima | Valor predial, autoavalúo por predio | informes@sat.gob.pe |
| Municipalidades | Catastro urbano detallado | Cada municipalidad distrital |

## Uso en Reco

### Valores arancelarios (MEF)
Se usan como **precio base mínimo** para la valorización IA. Si el precio de mercado
es menor al valor arancelario, es una señal de alerta en la ficha de la propiedad.

```javascript
// Ejemplo de uso en ValuationService
const valorArancel = valoresArancelarios[distrito][zona];
const descuentoSobreArancel = (precioMercado - valorArancel) / valorArancel;
```

### Zonificación (IMP)
Se muestra en la ficha de cada propiedad para indicar:
- Uso de suelo permitido
- Altura máxima edificable
- Coeficiente de edificación (potencial constructivo)
- Restricciones especiales

### Precios BCRP
Se usan para:
- Validar que las transacciones SUNARP están en rango razonable
- Calcular variación YoY por distrito
- Alimentar el PriceEvolutionChart en el full report

## Notas legales

Todos los datos en este repositorio provienen de fuentes públicas del Estado peruano
y pueden ser utilizados libremente con atribución. Ver licencias individuales por fuente.

VANET DATA S.A.C. — RUC 20553966800
contacto@reco.pe — Mayo 2026
