# Reco — Plataforma de Inteligencia Inmobiliaria para Lima y Perú

> *Descubre el precio real antes de comprar o vender. ¿Este depa está caro o barato?*

[![Datos](https://img.shields.io/badge/datos-847K_transacciones-blue)](data/)
[![Distritos](https://img.shields.io/badge/cobertura-43_distritos_Lima-green)](data/)
[![Empresa](https://img.shields.io/badge/VANET_DATA_SAC-RUC_20553966800-orange)](https://reco.pe)

## ¿Qué es Reco?

Reco cruza el precio de cualquier propiedad en Lima con **847,000+ transacciones
reales de SUNARP** — no con lo que los vendedores piden. Veredicto IA en 5 segundos.

## Estructura del repositorio

```
reco/
├── reco-v1.html              ← Frontend completo (SPA standalone)
├── docs/
│   └── reco_backend_arch.docx  ← Arquitectura de backend detallada
├── data/
│   ├── README.md             ← Documentación de fuentes
│   ├── valores_arancelarios_mef.json
│   ├── valores_construccion_mef.json
│   ├── serie_precios_bcrp.json
│   ├── zonificacion_lima_imp.json
│   ├── parametros_urbanisticos.csv
│   └── precios_distrito_2025.csv
└── README.md                 ← Este archivo
```

## Stack técnico (backend recomendado)

- **API**: Node.js 20 + TypeScript + Fastify
- **DB**: PostgreSQL 16 + PostGIS 3.4 (Supabase)
- **Cache**: Redis 7 (Upstash)
- **Queue**: BullMQ
- **ML**: Python + XGBoost (microservicio separado)
- **Pagos**: Culqi (único gateway con tarjetas peruanas)
- **Email**: Resend
- **Hosting**: Google Cloud Run

## Fuentes de datos

| Fuente | Tipo | Acceso |
|--------|------|--------|
| SUNARP | Partidas registrales | Convenio institucional |
| MEF | Valores unitarios oficiales | Público (PDFs anuales) |
| BCRP | Índice precios departamentos Lima | API pública gratuita |
| IMP | Zonificación Lima | Geoportal público |
| SIGRID/CENEPRED | Riesgo natural por zona | WMS/WFS público |
| COFOPRI | Catastro rural | Shapefiles públicos |

## Empresa

**VANET DATA S.A.C.**
RUC 20553966800 · Av. Manuel Olguín 327, Santiago de Surco, Lima
contacto@reco.pe

---

*Datos de valores unitarios: RM N°255-2025-EF/15 · Zonificación: IMP PLAM 2035 · Precios: BCRP Serie PN01289XM*
